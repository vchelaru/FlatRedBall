﻿using Bridge;
using Bridge.Html5;
using Bridge.WebGL;
using FlatRedBall;
using System;

namespace Cube3D
{
    public class Game1 : Game
    {
        public static string CanvasId = "canvas1";


        Sprite sprite;

        public Game1() : base()
        {

        }

        static Renderer renderer;
        protected override void Initialize()
        {
            renderer = new Renderer();

            renderer.Initialize(CanvasId);

            Console.WriteLine("Sprite");

            sprite = new Sprite();
            sprite.X = 3;
            sprite.Texture = FlatRedBallServices.Load("crate.gif");
            sprite.Y = 10;
            renderer.Sprites.Add(sprite);

            Console.WriteLine("Sprite");
            sprite = new Sprite();
            sprite.Texture = FlatRedBallServices.Load("blueguy.png");
            sprite.X = 10;
            sprite.Y = -10;
            renderer.Sprites.Add(sprite);

            Console.WriteLine("Sprite");
            sprite = new Sprite();
            sprite.Texture = FlatRedBallServices.Load("blueguy.png");
            sprite.X = 0;
            renderer.Sprites.Add(sprite);

            if (Renderer.WebGlRenderingContext != null)
            {
                Document.AddEventListener(EventType.KeyDown, renderer.HandleKeyDown);
                Document.AddEventListener(EventType.KeyUp, renderer.HandleKeyUp);
            }
            else
            {
                ShowError(renderer.canvas, "<b>Either the browser doesn't support WebGL or it is disabled.<br>Please follow <a href=\"http://get.webgl.com\">Get WebGL</a>.</b>");
            }

            base.Initialize();
        }

        protected override void Update()
        {
            sprite.X+=.05f;

            base.Update();
        }

        protected override void Draw()
        {

            renderer.Draw();

            base.Draw();
        }
    }
}
