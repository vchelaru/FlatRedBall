﻿using System.Reflection;
using System.Runtime.InteropServices;
using Bridge;

[assembly: AssemblyTitle("Cube3D")]
[assembly: AssemblyDescription("Bridge WebGL 3D Cube Demo")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Object.NET, Inc.")]
[assembly: AssemblyProduct("Cube3D")]
[assembly: AssemblyCopyright("Copyright 2008-2015 Object.NET, Inc.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("87fe353d-8cbc-4aa2-a56b-7cb4c0aa41d3")]
[assembly: AssemblyVersion("1.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

[assembly: Convention(Member = ConventionMember.Field | ConventionMember.Method, Notation = Notation.LowerCamelCase)]
[assembly: Convention(Target = ConventionTarget.ObjectLiteral, Member = ConventionMember.Property, Notation = Notation.LowerCamelCase)]
